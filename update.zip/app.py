from flask import Flask, render_template, request, jsonify, send_file, Response
import sqlite3
from datetime import datetime, timedelta
import json
import csv
import io
import os
import shutil
import schedule
import threading
import time
import zipfile

app = Flask(__name__)

# ==================== DATA FOLDER ====================
APP_DATA = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'OkandaPOS')
if not os.path.exists(APP_DATA):
    os.makedirs(APP_DATA)

DB_PATH = os.path.join(APP_DATA, 'pos_data.db')
BACKUP_FOLDER = os.path.join(APP_DATA, 'backups')
if not os.path.exists(BACKUP_FOLDER):
    os.makedirs(BACKUP_FOLDER)

# ==================== VERSION TRACKING (FIXED) ====================
VERSION_FILE = os.path.join(APP_DATA, 'version.txt')
CURRENT_VERSION = "1.0.1"   # CHANGE THIS TO YOUR NEW VERSION

def get_local_version():
    if os.path.exists(VERSION_FILE):
        with open(VERSION_FILE, 'r') as f:
            return f.read().strip()
    return CURRENT_VERSION

def save_local_version(version):
    with open(VERSION_FILE, 'w') as f:
        f.write(version)

# Sync: if CURRENT_VERSION is different from stored version, update the file
stored_version = get_local_version()
if stored_version != CURRENT_VERSION:
    save_local_version(CURRENT_VERSION)
    print(f"Version updated from {stored_version} to {CURRENT_VERSION}")

if not os.path.exists(VERSION_FILE):
    save_local_version(CURRENT_VERSION)

# ==================== DEVELOPER MODE DETECTION ====================
DEVELOPER_MODE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'developer_mode.txt')
IS_DEVELOPER = os.path.exists(DEVELOPER_MODE_FILE)

# ==================== BACKUP FUNCTIONS ====================
def create_backup():
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f'pos_data_backup_{timestamp}.db'
    backup_path = os.path.join(BACKUP_FOLDER, backup_name)
    shutil.copy2(DB_PATH, backup_path)
    backups = [f for f in os.listdir(BACKUP_FOLDER) if f.startswith('pos_data_backup_')]
    backups.sort(reverse=True)
    for old in backups[30:]:
        os.remove(os.path.join(BACKUP_FOLDER, old))
    return backup_name

def list_backups():
    backups = [f for f in os.listdir(BACKUP_FOLDER) if f.startswith('pos_data_backup_')]
    backups.sort(reverse=True)
    result = []
    for b in backups:
        stat = os.stat(os.path.join(BACKUP_FOLDER, b))
        result.append({
            'filename': b,
            'size': stat.st_size,
            'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
        })
    return result

def run_scheduled_backup():
    with app.app_context():
        backup_name = create_backup()
        print(f"Auto backup created: {backup_name}")

def start_scheduler():
    schedule.every().day.at("02:00").do(run_scheduled_backup)
    while True:
        schedule.run_pending()
        time.sleep(60)

scheduler_thread = threading.Thread(target=start_scheduler, daemon=True)
scheduler_thread.start()

# ==================== BACKUP API ROUTES ====================
@app.route('/api/backup', methods=['POST'])
def api_backup():
    try:
        backup_name = create_backup()
        return jsonify({'success': True, 'backup_file': backup_name})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/backups', methods=['GET'])
def api_list_backups():
    return jsonify({'success': True, 'backups': list_backups()})

@app.route('/api/restore', methods=['POST'])
def api_restore():
    data = request.json
    filename = data.get('filename')
    if not filename:
        return jsonify({'success': False, 'error': 'No filename'})
    backup_path = os.path.join(BACKUP_FOLDER, filename)
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'error': 'Backup not found'})
    try:
        shutil.copy2(backup_path, DB_PATH)
        return jsonify({'success': True, 'message': f'Restored from {filename}'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/delete_backup', methods=['POST'])
def api_delete_backup():
    data = request.json
    filename = data.get('filename')
    if not filename:
        return jsonify({'success': False, 'error': 'No filename'})
    backup_path = os.path.join(BACKUP_FOLDER, filename)
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'error': 'File not found'})
    try:
        os.remove(backup_path)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ==================== HOME ====================
@app.route('/')
def index():
    return render_template('index.html')

# ==================== VERSION & UPDATE APIS ====================
@app.route('/api/version')
def api_version():
    return jsonify({'version': get_local_version()})

@app.route('/api/developer_mode')
def api_developer_mode():
    return jsonify({'is_developer': IS_DEVELOPER})

@app.route('/api/apply_update', methods=['POST'])
def api_apply_update():
    if 'update_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    file = request.files['update_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'Empty filename'}), 400
    try:
        temp_zip = os.path.join(APP_DATA, 'update_temp.zip')
        file.save(temp_zip)
        extract_folder = os.path.join(APP_DATA, 'update_temp')
        if os.path.exists(extract_folder):
            shutil.rmtree(extract_folder)
        os.makedirs(extract_folder)
        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            zip_ref.extractall(extract_folder)
        app_dir = os.path.dirname(os.path.abspath(__file__))
        new_app = os.path.join(extract_folder, 'app.py')
        if os.path.exists(new_app):
            shutil.copy2(new_app, os.path.join(app_dir, 'app.py'))
        new_templates = os.path.join(extract_folder, 'templates')
        if os.path.exists(new_templates):
            old_templates = os.path.join(app_dir, 'templates')
            if os.path.exists(old_templates):
                shutil.rmtree(old_templates)
            shutil.copytree(new_templates, old_templates)
        version_txt = os.path.join(extract_folder, 'version.txt')
        if os.path.exists(version_txt):
            with open(version_txt, 'r') as vf:
                new_version = vf.read().strip()
                save_local_version(new_version)
        os.remove(temp_zip)
        shutil.rmtree(extract_folder)
        return jsonify({'success': True, 'message': 'Update applied. Please restart the server.'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/create_update_package', methods=['POST'])
def api_create_update_package():
    if not IS_DEVELOPER:
        return jsonify({'success': False, 'error': 'Not in developer mode'}), 403
    try:
        app_dir = os.path.dirname(os.path.abspath(__file__))
        zip_filename = f'update_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip'
        zip_path = os.path.join(app_dir, zip_filename)
        # Get the current version (which should already be synced)
        current_version = get_local_version()
        # Create version.txt in the project folder for upload
        version_txt_path = os.path.join(app_dir, 'version.txt')
        with open(version_txt_path, 'w') as vf:
            vf.write(current_version)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            zf.write(os.path.join(app_dir, 'app.py'), 'app.py')
            templates_dir = os.path.join(app_dir, 'templates')
            for root, dirs, files in os.walk(templates_dir):
                for file in files:
                    full_path = os.path.join(root, file)
                    arcname = os.path.relpath(full_path, app_dir)
                    zf.write(full_path, arcname)
            zf.write(version_txt_path, 'version.txt')
        # Also ensure the AppData version file is up to date
        save_local_version(current_version)
        return jsonify({'success': True, 'filename': zip_filename})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/download_update/<filename>')
def download_update(filename):
    app_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(app_dir, filename)
    if not os.path.exists(file_path):
        return "File not found", 404
    return send_file(file_path, as_attachment=True)

# ==================== DATABASE CONNECTION ====================
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ==================== PRODUCTS ====================
@app.route('/api/products')
def api_products():
    db = get_db()
    try:
        products = db.execute('''
            SELECT p.*, c.name as category_name, s.name as supplier_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN suppliers s ON p.supplier_id = s.id
            ORDER BY p.name
        ''').fetchall()
        return jsonify([dict(row) for row in products])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/product/by_barcode/<barcode>')
def api_product_by_barcode(barcode):
    db = get_db()
    try:
        product = db.execute('SELECT * FROM products WHERE barcode = ?', (barcode,)).fetchone()
        if product:
            return jsonify(dict(product))
        return jsonify({'error': 'Not found'}), 404
    finally:
        db.close()

@app.route('/api/product', methods=['POST'])
def api_create_product():
    data = request.json
    db = get_db()
    try:
        db.execute('''
            INSERT INTO products (name, sku, barcode, category_id, supplier_id, unit, price, cost_price, quantity, low_stock_threshold, tax_rate, expiry_date, batch_number)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['name'], data.get('sku'), data.get('barcode'),
            data.get('category_id'), data.get('supplier_id'), data.get('unit', 'piece'),
            data['price'], data.get('cost_price'), data.get('quantity', 0), data.get('low_stock_threshold', 0),
            data.get('tax_rate', 0), data.get('expiry_date'), data.get('batch_number')
        ))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/product/<int:id>', methods=['PUT'])
def api_update_product(id):
    data = request.json
    db = get_db()
    try:
        db.execute('''
            UPDATE products
            SET name=?, sku=?, barcode=?, category_id=?, supplier_id=?, unit=?, price=?, cost_price=?, quantity=?, low_stock_threshold=?, tax_rate=?, expiry_date=?, batch_number=?
            WHERE id=?
        ''', (
            data['name'], data.get('sku'), data.get('barcode'),
            data.get('category_id'), data.get('supplier_id'), data.get('unit'),
            data['price'], data.get('cost_price'), data['quantity'], data.get('low_stock_threshold', 0),
            data.get('tax_rate', 0), data.get('expiry_date'), data.get('batch_number'), id
        ))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/product/<int:id>', methods=['DELETE'])
def api_delete_product(id):
    db = get_db()
    try:
        db.execute('DELETE FROM products WHERE id=?', (id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== CATEGORIES ====================
@app.route('/api/categories')
def api_categories():
    db = get_db()
    try:
        cats = db.execute('SELECT * FROM categories ORDER BY name').fetchall()
        return jsonify([dict(row) for row in cats])
    finally:
        db.close()

@app.route('/api/category', methods=['POST'])
def api_create_category():
    data = request.json
    db = get_db()
    try:
        db.execute('INSERT INTO categories (name) VALUES (?)', (data['name'],))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/category/<int:id>', methods=['DELETE'])
def api_delete_category(id):
    db = get_db()
    try:
        used = db.execute('SELECT COUNT(*) as cnt FROM products WHERE category_id=?', (id,)).fetchone()['cnt']
        if used > 0:
            return jsonify({'success': False, 'error': 'Category has products'})
        db.execute('DELETE FROM categories WHERE id=?', (id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== SUPPLIERS ====================
@app.route('/api/suppliers')
def api_suppliers():
    db = get_db()
    try:
        suppliers = db.execute('SELECT * FROM suppliers ORDER BY name').fetchall()
        return jsonify([dict(row) for row in suppliers])
    finally:
        db.close()

@app.route('/api/supplier', methods=['POST'])
def api_create_supplier():
    data = request.json
    db = get_db()
    try:
        db.execute('''
            INSERT INTO suppliers (name, contact_person, phone, email, address, gst_number)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['name'], data.get('contact_person'), data.get('phone'), data.get('email'), data.get('address'), data.get('gst_number')))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/supplier/<int:id>', methods=['PUT'])
def api_update_supplier(id):
    data = request.json
    db = get_db()
    try:
        db.execute('''
            UPDATE suppliers
            SET name=?, contact_person=?, phone=?, email=?, address=?, gst_number=?
            WHERE id=?
        ''', (data['name'], data.get('contact_person'), data.get('phone'), data.get('email'), data.get('address'), data.get('gst_number'), id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/supplier/<int:id>', methods=['DELETE'])
def api_delete_supplier(id):
    db = get_db()
    try:
        used = db.execute('SELECT COUNT(*) as cnt FROM products WHERE supplier_id=?', (id,)).fetchone()['cnt']
        if used > 0:
            return jsonify({'success': False, 'error': 'Supplier has products'})
        db.execute('DELETE FROM suppliers WHERE id=?', (id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== SUPPLIER BILLS ====================
@app.route('/api/supplier_bills')
def api_supplier_bills():
    db = get_db()
    try:
        bills = db.execute('''
            SELECT sb.*, s.name as supplier_name
            FROM supplier_bills sb
            JOIN suppliers s ON sb.supplier_id = s.id
            ORDER BY sb.bill_date DESC
        ''').fetchall()
        return jsonify([dict(row) for row in bills])
    finally:
        db.close()

@app.route('/api/supplier_bill', methods=['POST'])
def api_create_supplier_bill():
    data = request.json
    db = get_db()
    try:
        db.execute('BEGIN TRANSACTION')
        cursor = db.execute('''
            INSERT INTO supplier_bills (bill_number, supplier_id, bill_date, total_amount, payment_status, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['bill_number'], data['supplier_id'], data['bill_date'], data['total_amount'], data.get('payment_status', 'pending'), data.get('notes')))
        bill_id = cursor.lastrowid
        for item in data['items']:
            db.execute('''
                INSERT INTO supplier_bill_items (supplier_bill_id, product_id, quantity, unit_price, total)
                VALUES (?, ?, ?, ?, ?)
            ''', (bill_id, item['product_id'], item['quantity'], item['unit_price'], item['total']))
            db.execute('''
                UPDATE products
                SET quantity = quantity + ?, cost_price = ?
                WHERE id = ?
            ''', (item['quantity'], item['unit_price'], item['product_id']))
            db.execute('''
                INSERT INTO stock_change_log (product_id, change_amount, reason, reference)
                VALUES (?, ?, ?, ?)
            ''', (item['product_id'], item['quantity'], 'purchase', data['bill_number']))
        db.commit()
        return jsonify({'success': True, 'bill_id': bill_id})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== SALES (grocery) ====================
@app.route('/api/sale', methods=['POST'])
def api_sale():
    data = request.json
    cart = data['cart']
    customer_id = data.get('customerId') if data.get('customerId') != '' else None
    payment_method = data['paymentMethod']
    paid_amount = float(data.get('paid', 0))
    db = get_db()
    try:
        db.execute('BEGIN TRANSACTION')
        invoice = f"INV-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        subtotal = 0
        tax_amount = 0
        for item in cart:
            item_subtotal = item['price'] * item['quantity']
            item_tax = item_subtotal * (item.get('tax_rate', 0) / 100)
            subtotal += item_subtotal
            tax_amount += item_tax
        total = subtotal + tax_amount
        due_amount = total - paid_amount
        if due_amount < 0:
            due_amount = 0
        db.execute('''
            INSERT INTO sales (invoice_number, customer_id, total_amount, tax_amount, payment_method, paid_amount, due_amount)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (invoice, customer_id, total, tax_amount, payment_method, paid_amount, due_amount))
        sale_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
        for item in cart:
            db.execute('''
                INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, tax_rate, total)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (sale_id, item['id'], item['quantity'], item['price'], item.get('tax_rate', 0), item['price'] * item['quantity']))
            db.execute('UPDATE products SET quantity = quantity - ? WHERE id = ?', (item['quantity'], item['id']))
            db.execute('''
                INSERT INTO stock_change_log (product_id, change_amount, reason, reference)
                VALUES (?, ?, ?, ?)
            ''', (item['id'], -item['quantity'], 'sale', invoice))
        if customer_id:
            points_earned = int(total / 100)
            if points_earned > 0:
                db.execute('UPDATE customers SET loyalty_points = loyalty_points + ? WHERE id = ?', (points_earned, customer_id))
        db.commit()
        return jsonify({'success': True, 'invoice': invoice, 'total': total, 'tax': tax_amount, 'due': due_amount})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== RETURN ====================
@app.route('/api/return', methods=['POST'])
def api_return():
    data = request.json
    cart = data['cart']
    customer_id = data.get('customerId')
    payment_method = data['paymentMethod']
    reason = data.get('reason', 'Return')
    db = get_db()
    try:
        db.execute('BEGIN TRANSACTION')
        invoice = f"RET-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        subtotal = 0
        tax_amount = 0
        for item in cart:
            item_subtotal = item['price'] * item['quantity']
            item_tax = item_subtotal * (item.get('tax_rate', 0) / 100)
            subtotal += item_subtotal
            tax_amount += item_tax
        total = subtotal + tax_amount
        db.execute('''
            INSERT INTO sales (invoice_number, customer_id, total_amount, tax_amount, payment_method, return_reason)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (invoice, customer_id, total, tax_amount, payment_method, reason))
        sale_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
        for item in cart:
            db.execute('''
                INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, tax_rate, total)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (sale_id, item['id'], -item['quantity'], item['price'], item.get('tax_rate', 0), -item['price'] * item['quantity']))
            db.execute('UPDATE products SET quantity = quantity + ? WHERE id = ?', (item['quantity'], item['id']))
            db.execute('''
                INSERT INTO stock_change_log (product_id, change_amount, reason, reference)
                VALUES (?, ?, ?, ?)
            ''', (item['id'], item['quantity'], 'return', invoice))
        db.commit()
        return jsonify({'success': True, 'invoice': invoice, 'refund_amount': total})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== CUSTOMERS ====================
@app.route('/api/customers')
def api_customers():
    db = get_db()
    try:
        customers = db.execute('SELECT * FROM customers ORDER BY name').fetchall()
        return jsonify([dict(row) for row in customers])
    finally:
        db.close()

@app.route('/api/customer', methods=['POST'])
def api_create_customer():
    data = request.json
    db = get_db()
    try:
        db.execute('''
            INSERT INTO customers (name, phone, email, address, credit_limit, credit_balance, loyalty_points)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (data['name'], data.get('phone'), data.get('email'), data.get('address'), data.get('credit_limit', 0), 0, 0))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/customer/<int:id>', methods=['PUT'])
def api_update_customer(id):
    data = request.json
    db = get_db()
    try:
        db.execute('''
            UPDATE customers
            SET name=?, phone=?, email=?, address=?, credit_limit=?
            WHERE id=?
        ''', (data['name'], data.get('phone'), data.get('email'), data.get('address'), data.get('credit_limit', 0), id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/customer/<int:id>', methods=['DELETE'])
def api_delete_customer(id):
    db = get_db()
    try:
        db.execute('DELETE FROM customers WHERE id=?', (id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/adjust_credit', methods=['POST'])
def api_adjust_credit():
    data = request.json
    db = get_db()
    try:
        db.execute('UPDATE customers SET credit_balance = credit_balance + ? WHERE id = ?', (data['amount'], data['customer_id']))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== CREDIT INVOICES & SUMMARY ====================
@app.route('/api/customer/credit_invoices/<int:customer_id>')
def api_credit_invoices(customer_id):
    db = get_db()
    try:
        invoices = db.execute('''
            SELECT invoice_number, sale_date, total_amount, paid_amount, due_amount
            FROM sales
            WHERE customer_id = ? AND payment_method = 'credit'
            ORDER BY sale_date ASC
        ''', (customer_id,)).fetchall()
        return jsonify([dict(row) for row in invoices])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/customer/credit_summary/<int:customer_id>')
def api_credit_summary(customer_id):
    db = get_db()
    try:
        total_credit = db.execute('''
            SELECT COALESCE(SUM(total_amount), 0) as total_credit
            FROM sales
            WHERE customer_id = ? AND payment_method = 'credit'
        ''', (customer_id,)).fetchone()['total_credit']
        outstanding = db.execute('''
            SELECT COALESCE(SUM(due_amount), 0) as outstanding
            FROM sales
            WHERE customer_id = ? AND payment_method = 'credit'
        ''', (customer_id,)).fetchone()['outstanding']
        return jsonify({'total_credit': total_credit, 'outstanding': outstanding})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

# ==================== GLOBAL PAYMENT ====================
@app.route('/api/customer/payment_history/<int:customer_id>')
def api_payment_history(customer_id):
    db = get_db()
    try:
        payments = db.execute('''
            SELECT amount, payment_date, notes
            FROM credit_payments
            WHERE customer_id = ?
            ORDER BY payment_date DESC
        ''', (customer_id,)).fetchall()
        return jsonify([dict(row) for row in payments])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/record_global_payment', methods=['POST'])
def api_record_global_payment():
    data = request.json
    customer_id = data.get('customer_id')
    amount = float(data.get('amount', 0))
    notes = data.get('notes', '')
    if not customer_id or amount <= 0:
        return jsonify({'success': False, 'error': 'Invalid customer or amount'}), 400
    db = get_db()
    try:
        db.execute('BEGIN TRANSACTION')
        invoices = db.execute('''
            SELECT id, due_amount
            FROM sales
            WHERE customer_id = ? AND payment_method = 'credit' AND due_amount > 0
            ORDER BY sale_date ASC
        ''', (customer_id,)).fetchall()
        remaining = amount
        for inv in invoices:
            if remaining <= 0:
                break
            due = float(inv['due_amount'])
            if remaining >= due:
                db.execute('UPDATE sales SET paid_amount = total_amount, due_amount = 0 WHERE id = ?', (inv['id'],))
                remaining -= due
            else:
                current = db.execute('SELECT paid_amount FROM sales WHERE id = ?', (inv['id'],)).fetchone()
                new_paid = current['paid_amount'] + remaining
                new_due = due - remaining
                db.execute('UPDATE sales SET paid_amount = ?, due_amount = ? WHERE id = ?', (new_paid, new_due, inv['id']))
                remaining = 0
        db.execute('INSERT INTO credit_payments (customer_id, amount, notes) VALUES (?, ?, ?)', (customer_id, amount, notes))
        db.commit()
        return jsonify({'success': True, 'applied_amount': amount - remaining})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== CREDIT SALE ====================
@app.route('/api/credit_sale', methods=['POST'])
def api_credit_sale():
    data = request.json
    cart = data['cart']
    customer_id = data['customer_id']
    total = data['total']
    db = get_db()
    try:
        customer = db.execute("SELECT credit_limit, credit_balance FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not customer:
            return jsonify({'success': False, 'error': 'Customer not found'})
        new_balance = customer['credit_balance'] + total
        if new_balance > customer['credit_limit']:
            return jsonify({'success': False, 'error': 'Credit limit exceeded'})
        invoice = f"CR-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        db.execute('BEGIN TRANSACTION')
        db.execute('''
            INSERT INTO sales (invoice_number, customer_id, total_amount, due_amount, payment_method)
            VALUES (?, ?, ?, ?, ?)
        ''', (invoice, customer_id, total, total, 'credit'))
        sale_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
        for item in cart:
            db.execute('''
                INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, tax_rate, total)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (sale_id, item['id'], item['quantity'], item['price'], item.get('tax_rate', 0), item['price'] * item['quantity']))
            db.execute("UPDATE products SET quantity = quantity - ? WHERE id = ?", (item['quantity'], item['id']))
            db.execute('''
                INSERT INTO stock_change_log (product_id, change_amount, reason, reference)
                VALUES (?, ?, ?, ?)
            ''', (item['id'], -item['quantity'], 'credit_sale', invoice))
        db.execute("UPDATE customers SET credit_balance = ? WHERE id = ?", (new_balance, customer_id))
        db.commit()
        return jsonify({'success': True, 'invoice': invoice, 'due': total})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== PARTIAL PAYMENT ====================
@app.route('/api/partial_payment', methods=['POST'])
def api_partial_payment():
    data = request.json
    invoice = data['invoice']
    amount = data['amount']
    db = get_db()
    try:
        sale = db.execute("SELECT total_amount, paid_amount FROM sales WHERE invoice_number = ?", (invoice,)).fetchone()
        if not sale:
            return jsonify({'success': False, 'error': 'Invoice not found'})
        new_paid = sale['paid_amount'] + amount
        if new_paid > sale['total_amount']:
            return jsonify({'success': False, 'error': 'Overpayment'})
        due = sale['total_amount'] - new_paid
        db.execute("UPDATE sales SET paid_amount = ?, due_amount = ? WHERE invoice_number = ?", (new_paid, due, invoice))
        db.commit()
        return jsonify({'success': True, 'due': due})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== SUSPENDED CARTS ====================
@app.route('/api/suspend_cart', methods=['POST'])
def api_suspend_cart():
    data = request.json
    cart_json = json.dumps(data['cart'])
    customer_id = data.get('customer_id')
    db = get_db()
    try:
        db.execute("INSERT INTO suspended_carts (cart_data, customer_id) VALUES (?, ?)", (cart_json, customer_id))
        cart_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
        db.commit()
        return jsonify({'success': True, 'cart_id': cart_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/suspended_carts')
def api_suspended_carts():
    db = get_db()
    try:
        carts = db.execute("SELECT id, created_at FROM suspended_carts ORDER BY created_at DESC").fetchall()
        return jsonify([dict(row) for row in carts])
    finally:
        db.close()

@app.route('/api/resume_cart/<int:cart_id>')
def api_resume_cart(cart_id):
    db = get_db()
    try:
        row = db.execute("SELECT cart_data, customer_id FROM suspended_carts WHERE id = ?", (cart_id,)).fetchone()
        if not row:
            return jsonify({'error': 'Not found'}), 404
        cart = json.loads(row['cart_data'])
        db.execute("DELETE FROM suspended_carts WHERE id = ?", (cart_id,))
        db.commit()
        return jsonify({'success': True, 'cart': cart, 'customer_id': row['customer_id']})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

# ==================== CUSTOMER HISTORY ====================
@app.route('/api/customer/history/<int:customer_id>')
def api_customer_history(customer_id):
    db = get_db()
    try:
        sales = db.execute('''
            SELECT invoice_number, sale_date, total_amount, payment_method
            FROM sales
            WHERE customer_id = ?
            ORDER BY sale_date DESC
        ''', (customer_id,)).fetchall()
        return jsonify([dict(row) for row in sales])
    finally:
        db.close()

# ==================== PROFIT REPORT ====================
@app.route('/api/profit_report', methods=['GET'])
def api_profit_report():
    period = request.args.get('period', 'day')
    db = get_db()
    try:
        if period == 'day':
            group = "date(sale_date)"
            date_limit = "date(sale_date) = date('now')"
        elif period == 'week':
            group = "strftime('%Y-%W', sale_date)"
            date_limit = "sale_date >= date('now', '-7 days')"
        else:
            group = "strftime('%Y-%m', sale_date)"
            date_limit = "sale_date >= date('now', '-30 days')"
        query = f'''
            SELECT {group} as period,
                   SUM(s.total_amount) as revenue,
                   SUM(si.quantity * p.cost_price) as cost_of_goods_sold,
                   SUM(s.total_amount) - SUM(si.quantity * p.cost_price) as profit
            FROM sales s
            JOIN sale_items si ON s.id = si.sale_id
            JOIN products p ON si.product_id = p.id
            WHERE {date_limit}
            GROUP BY period
            ORDER BY period
        '''
        rows = db.execute(query).fetchall()
        return jsonify([dict(row) for row in rows])
    finally:
        db.close()

# ==================== STOCK LOG ====================
@app.route('/api/stock_log')
def api_stock_log():
    db = get_db()
    try:
        logs = db.execute('''
            SELECT l.*, p.name as product_name
            FROM stock_change_log l
            JOIN products p ON l.product_id = p.id
            ORDER BY l.created_at DESC
            LIMIT 200
        ''').fetchall()
        return jsonify([dict(row) for row in logs])
    finally:
        db.close()

@app.route('/api/stock_adjust', methods=['POST'])
def api_stock_adjust():
    data = request.json
    product_id = data['product_id']
    change = data['change']
    reason = data['reason']
    reference = data.get('reference', 'manual')
    db = get_db()
    try:
        db.execute("UPDATE products SET quantity = quantity + ? WHERE id = ?", (change, product_id))
        db.execute("INSERT INTO stock_change_log (product_id, change_amount, reason, reference) VALUES (?, ?, ?, ?)",
                   (product_id, change, reason, reference))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== EXPIRY ALERTS ====================
@app.route('/api/expiry_alerts')
def api_expiry_alerts():
    db = get_db()
    try:
        today = datetime.now().date()
        warning_date = today + timedelta(days=7)
        products = db.execute('''
            SELECT id, name, expiry_date, quantity, unit
            FROM products
            WHERE expiry_date IS NOT NULL AND expiry_date <= ?
            ORDER BY expiry_date
        ''', (warning_date,)).fetchall()
        return jsonify([dict(row) for row in products])
    finally:
        db.close()

# ==================== PROMOTIONS ====================
@app.route('/api/promotions')
def api_promotions():
    db = get_db()
    try:
        today = datetime.now().date().isoformat()
        promos = db.execute('''
            SELECT * FROM promotions
            WHERE active = 1 AND (start_date IS NULL OR start_date <= ?) AND (end_date IS NULL OR end_date >= ?)
        ''', (today, today)).fetchall()
        return jsonify([dict(row) for row in promos])
    finally:
        db.close()

@app.route('/api/promotion', methods=['POST', 'PUT', 'DELETE'])
def api_manage_promotion():
    db = get_db()
    try:
        if request.method == 'POST':
            data = request.json
            db.execute('''
                INSERT INTO promotions (name, type, value, min_cart_value, product_id, min_quantity, start_date, end_date, active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (data['name'], data['type'], data.get('value'), data.get('min_cart_value'), data.get('product_id'),
                  data.get('min_quantity'), data.get('start_date'), data.get('end_date'), data.get('active', 1)))
            db.commit()
            return jsonify({'success': True})
        elif request.method == 'PUT':
            data = request.json
            db.execute('''
                UPDATE promotions SET active = ? WHERE id = ?
            ''', (data['active'], data['id']))
            db.commit()
            return jsonify({'success': True})
        else:  # DELETE
            pid = request.args.get('id')
            db.execute("DELETE FROM promotions WHERE id = ?", (pid,))
            db.commit()
            return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== REDEEM POINTS ====================
@app.route('/api/redeem_points', methods=['POST'])
def api_redeem_points():
    data = request.json
    customer_id = data['customer_id']
    points = data['points']
    db = get_db()
    try:
        customer = db.execute("SELECT loyalty_points FROM customers WHERE id = ?", (customer_id,)).fetchone()
        if not customer or customer['loyalty_points'] < points:
            return jsonify({'success': False, 'error': 'Insufficient points'})
        discount = points
        new_points = customer['loyalty_points'] - points
        db.execute("UPDATE customers SET loyalty_points = ? WHERE id = ?", (new_points, customer_id))
        db.commit()
        return jsonify({'success': True, 'discount': discount})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== DASHBOARD STATS ====================
@app.route('/api/dashboard/stats')
def api_dashboard_stats():
    db = get_db()
    try:
        today = datetime.now().date()
        dates = [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(6, -1, -1)]
        daily_totals = []
        for d in dates:
            total = db.execute('SELECT SUM(total_amount) as sum FROM sales WHERE date(sale_date) = ?', (d,)).fetchone()['sum'] or 0
            daily_totals.append(total)
        top_products = db.execute('''
            SELECT p.name, SUM(si.quantity) as total_qty
            FROM sale_items si
            JOIN products p ON si.product_id = p.id
            JOIN sales s ON si.sale_id = s.id
            WHERE s.sale_date >= date('now', '-30 days')
            GROUP BY p.id
            ORDER BY total_qty DESC
            LIMIT 5
        ''').fetchall()
        low_stock_count = db.execute('SELECT COUNT(*) as cnt FROM products WHERE quantity <= low_stock_threshold AND low_stock_threshold > 0').fetchone()['cnt']
        return jsonify({
            'labels': dates,
            'daily_sales': daily_totals,
            'top_products': [dict(row) for row in top_products],
            'low_stock_count': low_stock_count
        })
    finally:
        db.close()

# ==================== DAILY REPORT ====================
@app.route('/api/reports/daily')
def api_daily_report():
    db = get_db()
    try:
        today = datetime.now().strftime('%Y-%m-%d')
        sales = db.execute('SELECT * FROM sales WHERE date(sale_date) = ? ORDER BY sale_date DESC', (today,)).fetchall()
        total = db.execute('SELECT SUM(total_amount) as sum FROM sales WHERE date(sale_date) = ?', (today,)).fetchone()['sum'] or 0
        return jsonify({'sales': [dict(row) for row in sales], 'total_today': total})
    finally:
        db.close()

@app.route('/api/reports/lowstock')
def api_low_stock():
    db = get_db()
    try:
        low = db.execute('''
            SELECT * FROM products
            WHERE quantity <= low_stock_threshold AND low_stock_threshold > 0
            ORDER BY quantity ASC
        ''').fetchall()
        return jsonify([dict(row) for row in low])
    finally:
        db.close()

# ==================== PAST INVOICES ====================
@app.route('/api/invoices/recent')
def api_recent_invoices():
    db = get_db()
    try:
        invoices = db.execute('''
            SELECT invoice_number, sale_date, total_amount, payment_method
            FROM sales
            ORDER BY sale_date DESC
            LIMIT 30
        ''').fetchall()
        return jsonify([dict(row) for row in invoices])
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

# ==================== BULK IMPORT ====================
@app.route('/api/import/<entity>', methods=['POST'])
def api_import(entity):
    file = request.files['file']
    if not file:
        return jsonify({'success': False, 'error': 'No file'})
    stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
    csv_input = csv.reader(stream)
    next(csv_input)  # skip header
    db = get_db()
    count = 0
    try:
        if entity == 'products':
            for row in csv_input:
                row = list(row) + [''] * 10
                name, price, quantity, unit, tax_rate, cat_name, sup_name, barcode, cost_price, low_stock = row[:10]
                cat_id = None
                if cat_name:
                    c = db.execute("SELECT id FROM categories WHERE name = ?", (cat_name,)).fetchone()
                    if c:
                        cat_id = c['id']
                    else:
                        db.execute("INSERT INTO categories (name) VALUES (?)", (cat_name,))
                        cat_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
                sup_id = None
                if sup_name:
                    s = db.execute("SELECT id FROM suppliers WHERE name = ?", (sup_name,)).fetchone()
                    if s:
                        sup_id = s['id']
                    else:
                        db.execute("INSERT INTO suppliers (name) VALUES (?)", (sup_name,))
                        sup_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
                db.execute('''
                    INSERT INTO products (name, price, quantity, unit, tax_rate, category_id, supplier_id, barcode, cost_price, low_stock_threshold)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (name, float(price), float(quantity), unit, float(tax_rate), cat_id, sup_id, barcode, float(cost_price) if cost_price else None, float(low_stock) if low_stock else 0))
                count += 1
        elif entity == 'customers':
            for row in csv_input:
                row = list(row) + [''] * 4
                name, phone, email, address = row[:4]
                db.execute("INSERT INTO customers (name, phone, email, address) VALUES (?, ?, ?, ?)", (name, phone, email, address))
                count += 1
        elif entity == 'suppliers':
            for row in csv_input:
                row = list(row) + [''] * 6
                name, contact, phone, email, address, gst = row[:6]
                db.execute("INSERT INTO suppliers (name, contact_person, phone, email, address, gst_number) VALUES (?, ?, ?, ?, ?, ?)",
                           (name, contact, phone, email, address, gst))
                count += 1
        db.commit()
        return jsonify({'success': True, 'count': count})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

# ==================== EXPORT ====================
@app.route('/api/export/sales')
def api_export_sales():
    db = get_db()
    try:
        sales = db.execute('''
            SELECT s.invoice_number, s.sale_date, c.name as customer, s.total_amount, s.tax_amount, s.payment_method
            FROM sales s
            LEFT JOIN customers c ON s.customer_id = c.id
            ORDER BY s.sale_date DESC
        ''').fetchall()
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Invoice', 'Date', 'Customer', 'Total (Rs)', 'Tax (Rs)', 'Payment Method'])
        for row in sales:
            writer.writerow([row['invoice_number'], row['sale_date'], row['customer'], row['total_amount'], row['tax_amount'], row['payment_method']])
        output.seek(0)
        return Response(output, mimetype='text/csv', headers={"Content-Disposition": "attachment;filename=sales_export.csv"})
    finally:
        db.close()

@app.route('/api/export/quickbooks')
def api_export_quickbooks():
    db = get_db()
    try:
        sales = db.execute('''
            SELECT s.sale_date, s.invoice_number, s.total_amount, s.tax_amount
            FROM sales s
            ORDER BY s.sale_date DESC
        ''').fetchall()
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Date', 'Invoice No', 'Total', 'Tax'])
        for row in sales:
            writer.writerow([row['sale_date'], row['invoice_number'], row['total_amount'], row['tax_amount']])
        output.seek(0)
        return Response(output, mimetype='text/csv', headers={"Content-Disposition": "attachment;filename=quickbooks_export.csv"})
    finally:
        db.close()

@app.route('/api/report/pdf', methods=['POST'])
def api_report_pdf():
    data = request.json
    report_type = data['type']
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
        buffer = io.BytesIO()
        c = canvas.Canvas(buffer, pagesize=letter)
        c.drawString(100, 750, f"Okanda Grocery Store - {report_type.upper()} Report")
        c.drawString(100, 730, f"Generated: {datetime.now()}")
        c.drawString(100, 700, "This is a placeholder. Export to CSV for full data.")
        c.showPage()
        c.save()
        buffer.seek(0)
        return send_file(buffer, as_attachment=True, download_name=f"{report_type}_report.pdf", mimetype='application/pdf')
    except ImportError:
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Install reportlab for PDF generation."])
        output.seek(0)
        return Response(output, mimetype='text/csv', headers={"Content-Disposition": f"attachment;filename={report_type}_report.csv"})

# ==================== BILL PRINTING (grocery) ====================
@app.route('/api/bill/<invoice>')
def api_bill(invoice):
    db = get_db()
    try:
        sale = db.execute('SELECT * FROM sales WHERE invoice_number = ?', (invoice,)).fetchone()
        if not sale:
            return "Bill not found"
        items = db.execute('''
            SELECT p.name, p.unit, si.quantity, si.unit_price, si.tax_rate, si.total
            FROM sale_items si
            JOIN products p ON si.product_id = p.id
            WHERE si.sale_id = ?
        ''', (sale['id'],)).fetchall()
        items_rows = ''
        for item in items:
            items_rows += f'''
                <tr>
                    <td>{item["name"]}</td>
                    <td>{item["quantity"]:.3f} {item["unit"]}</td>
                    <td>Rs{item["unit_price"]:.2f}</td>
                    <td>Rs{abs(item["total"]):.2f}</td>
                </tr>
            '''
        html = f'''
        <html>
        <head><title>Invoice {invoice}</title>
        <style>
            body {{ font-family: monospace; width: 80mm; margin: auto; }}
            .center {{ text-align: center; }}
            table {{ width: 100%; }}
            th, td {{ text-align: left; }}
            .total {{ font-weight: bold; }}
        </style>
        </head>
        <body>
            <div class="center">
                <h2>Okanda Grocery Store</h2>
                <p>Invoice: {invoice}<br>Date: {sale['sale_date']}</p>
            </div>
            <hr>
            <table>
                <tr><th>Item</th><th>Qty</th><th>Price (Rs)</th><th>Total (Rs)</th></tr>
                {items_rows}
            </table>
            <hr>
            <p>Subtotal: Rs{sale['total_amount'] - sale['tax_amount']:.2f}<br>
            Tax: Rs{sale['tax_amount']:.2f}<br>
            <strong>Total: Rs{sale['total_amount']:.2f}</strong><br>
            Payment: {sale['payment_method']}<br>
            Thank you!</p>
        </body>
        </html>
        '''
        return html
    finally:
        db.close()

# ==================== RESTAURANT API ROUTES ====================
@app.route('/api/restaurant/tables', methods=['GET'])
def api_restaurant_tables():
    db = get_db()
    try:
        tables = db.execute('SELECT * FROM restaurant_tables ORDER BY table_number').fetchall()
        return jsonify([dict(row) for row in tables])
    finally:
        db.close()

@app.route('/api/restaurant/table', methods=['POST'])
def api_restaurant_create_table():
    data = request.json
    db = get_db()
    try:
        db.execute('INSERT INTO restaurant_tables (table_number, capacity) VALUES (?, ?)',
                   (data['table_number'], data.get('capacity', 2)))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/table/<int:table_id>', methods=['PUT'])
def api_restaurant_update_table(table_id):
    data = request.json
    db = get_db()
    try:
        db.execute('UPDATE restaurant_tables SET table_number=?, capacity=?, status=? WHERE id=?',
                   (data['table_number'], data['capacity'], data.get('status', 'free'), table_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/table/<int:table_id>', methods=['DELETE'])
def api_restaurant_delete_table(table_id):
    db = get_db()
    try:
        active = db.execute('SELECT COUNT(*) as cnt FROM orders WHERE table_id=? AND status != "completed"', (table_id,)).fetchone()['cnt']
        if active > 0:
            return jsonify({'success': False, 'error': 'Table has active orders'}), 400
        db.execute('DELETE FROM restaurant_tables WHERE id=?', (table_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/orders', methods=['GET'])
def api_restaurant_orders():
    db = get_db()
    try:
        orders = db.execute('''
            SELECT o.*, t.table_number
            FROM orders o
            JOIN restaurant_tables t ON o.table_id = t.id
            ORDER BY o.created_at DESC
        ''').fetchall()
        return jsonify([dict(row) for row in orders])
    finally:
        db.close()

@app.route('/api/restaurant/order', methods=['POST'])
def api_restaurant_create_order():
    data = request.json
    table_id = data['table_id']
    db = get_db()
    try:
        order_number = f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        db.execute('INSERT INTO orders (table_id, order_number, status) VALUES (?, ?, ?)',
                   (table_id, order_number, 'pending'))
        order_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]
        db.execute('UPDATE restaurant_tables SET status = "occupied" WHERE id = ?', (table_id,))
        db.commit()
        return jsonify({'success': True, 'order_id': order_id, 'order_number': order_number})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/order/<int:order_id>/add_item', methods=['POST'])
def api_restaurant_add_order_item(order_id):
    data = request.json
    db = get_db()
    try:
        product_id = data['product_id']
        quantity = data['quantity']
        unit_price = data['unit_price']
        tax_rate = data.get('tax_rate', 0)
        modifiers = json.dumps(data.get('modifiers', {}))
        instructions = data.get('instructions', '')
        course = data.get('course', 'main')
        total = unit_price * quantity * (1 + tax_rate/100)
        db.execute('''
            INSERT INTO order_items (order_id, product_id, quantity, unit_price, tax_rate, modifiers, instructions, course, total)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (order_id, product_id, quantity, unit_price, tax_rate, modifiers, instructions, course, total))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/order/<int:order_id>/items')
def api_restaurant_order_items(order_id):
    db = get_db()
    try:
        items = db.execute('''
            SELECT oi.*, p.name as product_name
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ''', (order_id,)).fetchall()
        return jsonify([dict(row) for row in items])
    finally:
        db.close()

@app.route('/api/restaurant/order/<int:order_id>/status', methods=['PUT'])
def api_restaurant_update_order_status(order_id):
    data = request.json
    status = data['status']
    db = get_db()
    try:
        db.execute('UPDATE orders SET status = ? WHERE id = ?', (status, order_id))
        if status == 'completed':
            db.execute('UPDATE orders SET completed_at = CURRENT_TIMESTAMP WHERE id = ?', (order_id,))
            table_id = db.execute('SELECT table_id FROM orders WHERE id = ?', (order_id,)).fetchone()['table_id']
            other_active = db.execute('SELECT COUNT(*) as cnt FROM orders WHERE table_id=? AND status != "completed"', (table_id,)).fetchone()['cnt']
            if other_active == 0:
                db.execute('UPDATE restaurant_tables SET status = "free" WHERE id = ?', (table_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/order/<int:order_id>/item/<int:item_id>/serve', methods=['PUT'])
def api_restaurant_mark_item_served(order_id, item_id):
    db = get_db()
    try:
        db.execute('UPDATE order_items SET served = 1 WHERE id = ? AND order_id = ?', (item_id, order_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/kitchen')
def api_restaurant_kitchen():
    db = get_db()
    try:
        orders = db.execute('''
            SELECT o.id, o.order_number, t.table_number, o.status
            FROM orders o
            JOIN restaurant_tables t ON o.table_id = t.id
            WHERE o.status IN ('pending', 'in_progress')
            ORDER BY o.created_at ASC
        ''').fetchall()
        result = []
        for order in orders:
            items = db.execute('''
                SELECT oi.*, p.name as product_name
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = ? AND oi.served = 0
            ''', (order['id'],)).fetchall()
            result.append({
                'order': dict(order),
                'items': [dict(item) for item in items]
            })
        return jsonify(result)
    finally:
        db.close()

@app.route('/api/restaurant/order/<int:order_id>/split', methods=['POST'])
def api_restaurant_split_bill(order_id):
    data = request.json
    splits = data['splits']
    db = get_db()
    try:
        for split in splits:
            db.execute('''
                INSERT INTO split_payments (order_id, amount, customer_name, payment_method)
                VALUES (?, ?, ?, ?)
            ''', (order_id, split['amount'], split.get('customer_name', ''), split.get('payment_method', 'cash')))
        db.execute('UPDATE orders SET status = "completed", completed_at = CURRENT_TIMESTAMP WHERE id = ?', (order_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        db.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/completed_orders')
def api_restaurant_completed_orders():
    db = get_db()
    try:
        orders = db.execute('''
            SELECT o.id as order_id, o.order_number, o.completed_at, 
                   COALESCE(SUM(oi.total), 0) as total_amount,
                   t.table_number
            FROM orders o
            JOIN restaurant_tables t ON o.table_id = t.id
            LEFT JOIN order_items oi ON o.id = oi.order_id
            WHERE o.status = 'completed'
              AND o.completed_at >= date('now', '-20 days')
            GROUP BY o.id
            ORDER BY o.completed_at DESC
        ''').fetchall()
        result = []
        for row in orders:
            splits = db.execute('SELECT COUNT(*) as cnt FROM split_payments WHERE order_id = ?', (row['order_id'],)).fetchone()['cnt']
            payment_method = 'Split' if splits > 0 else 'Completed'
            result.append({
                'order_id': row['order_id'],
                'order_number': row['order_number'],
                'completed_at': row['completed_at'],
                'total_amount': float(row['total_amount']),
                'payment_method': payment_method,
                'table_number': row['table_number']
            })
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route('/api/restaurant/bill/<int:order_id>')
def api_restaurant_bill(order_id):
    db = get_db()
    try:
        order = db.execute('''
            SELECT o.order_number, o.completed_at, t.table_number
            FROM orders o
            JOIN restaurant_tables t ON o.table_id = t.id
            WHERE o.id = ?
        ''', (order_id,)).fetchone()
        if not order:
            return "Order not found"
        items = db.execute('''
            SELECT oi.*, p.name as product_name, p.unit
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ''', (order_id,)).fetchall()
        total = sum(item['total'] for item in items)
        items_rows = ''
        for item in items:
            items_rows += f'''
            <tr>
                <td>{item["product_name"]}</td>
                <td>{item["quantity"]:.2f} {item["unit"]}</td>
                <td>Rs{item["unit_price"]:.2f}</td>
                <td>Rs{item["total"]:.2f}</td>
            </tr>
            '''
        html = f'''
        <html>
        <head><title>Restaurant Bill - {order['order_number']}</title>
        <style>
            body {{ font-family: monospace; width: 80mm; margin: auto; }}
            .center {{ text-align: center; }}
            table {{ width: 100%; }}
            th, td {{ text-align: left; }}
            .total {{ font-weight: bold; }}
        </style>
        </head>
        <body>
            <div class="center">
                <h2>Okanda Restaurant</h2>
                <p>Order: {order['order_number']}<br>Table: {order['table_number']}<br>Date: {order['completed_at']}</p>
            </div>
            <hr>
            <tr>
                <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
                {items_rows}
            </table>
            <hr>
            <p><strong>Total: Rs{total:.2f}</strong><br>
            Thank you for dining with us!</p>
        </body>
        </html>
        '''
        return html
    finally:
        db.close()

# ==================== START SERVER ====================
if __name__ == '__main__':
    import threading
    import webbrowser
    import time

    def open_browser():
        time.sleep(1.5)
        webbrowser.open('http://127.0.0.1:5000')

    threading.Thread(target=open_browser, daemon=True).start()
    app.run(debug=True, host='127.0.0.1', port=5000)